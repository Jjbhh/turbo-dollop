package com.starknetwork.randomkit;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class KitCommand implements CommandExecutor, TabCompleter {

    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_-]{1,32}");
    private static final List<String> SUBS =
            List.of("create", "update", "delete", "list", "preview", "give", "random", "reload", "help");

    private final RandomKitPlugin plugin;
    private final KitManager kits;

    public KitCommand(RandomKitPlugin plugin, KitManager kits) {
        this.plugin = plugin;
        this.kits = kits;
    }

    public static class PreviewHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("randomkit.admin")) {
            RandomKitPlugin.send(sender, "&cYou do not have permission.");
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            help(sender, label);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create", "update" -> save(sender, args, args[0].equalsIgnoreCase("update"));
            case "delete" -> delete(sender, args);
            case "list" -> list(sender);
            case "preview" -> preview(sender, args);
            case "give" -> give(sender, args, false);
            case "random" -> give(sender, args, true);
            case "reload" -> {
                plugin.reloadSettings();
                kits.reloadAsync(ok -> RandomKitPlugin.send(sender, ok
                        ? "Reloaded. &e" + kits.size() + "&7 kit(s) loaded."
                        : "&cReload failed, check the console."));
            }
            default -> help(sender, label);
        }
        return true;
    }

    private void help(CommandSender s, String label) {
        RandomKitPlugin.send(s, "&e/" + label + " create <name> &8- &7Save your inventory as a new kit");
        RandomKitPlugin.send(s, "&e/" + label + " update <name> &8- &7Overwrite a kit with your inventory");
        RandomKitPlugin.send(s, "&e/" + label + " delete <name> &8- &7Delete a kit");
        RandomKitPlugin.send(s, "&e/" + label + " list &8- &7List all kits");
        RandomKitPlugin.send(s, "&e/" + label + " preview <name> &8- &7Preview a kit");
        RandomKitPlugin.send(s, "&e/" + label + " give <player> <name> &8- &7Give a specific kit");
        RandomKitPlugin.send(s, "&e/" + label + " random <player> &8- &7Give a random kit");
        RandomKitPlugin.send(s, "&e/" + label + " reload &8- &7Reload config and kits");
    }

    private void save(CommandSender sender, String[] args, boolean update) {
        if (!(sender instanceof Player p)) {
            RandomKitPlugin.send(sender, "&cOnly players can use this.");
            return;
        }
        if (args.length < 2) {
            RandomKitPlugin.send(sender, "&cUsage: /randomkit " + (update ? "update" : "create") + " <name>");
            return;
        }
        String name = args[1];
        if (!NAME.matcher(name).matches()) {
            RandomKitPlugin.send(sender, "&cKit names may only contain letters, numbers, - and _ (max 32).");
            return;
        }
        boolean exists = kits.exists(name);
        if (!update && exists) {
            RandomKitPlugin.send(sender, "&cThat kit already exists. Use &e/randomkit update " + name + "&c to overwrite it.");
            return;
        }
        if (update && !exists) {
            RandomKitPlugin.send(sender, "&cThat kit does not exist. Use &e/randomkit create " + name + "&c.");
            return;
        }
        if (update) name = kits.get(name).name();
        if (!kits.capture(p, name)) {
            RandomKitPlugin.send(sender, "&cYour inventory is empty.");
            return;
        }
        RandomKitPlugin.send(sender, "Kit &e" + name + "&7 " + (update ? "updated" : "created")
                + " &8(&7total: &e" + kits.size() + "&8)");
    }

    private void delete(CommandSender sender, String[] args) {
        if (args.length < 2) {
            RandomKitPlugin.send(sender, "&cUsage: /randomkit delete <name>");
            return;
        }
        if (kits.delete(args[1])) {
            RandomKitPlugin.send(sender, "Kit &e" + args[1] + "&7 deleted. &8(&7total: &e" + kits.size() + "&8)");
        } else {
            RandomKitPlugin.send(sender, "&cKit not found.");
        }
    }

    private void list(CommandSender sender) {
        if (kits.size() == 0) {
            RandomKitPlugin.send(sender, "&cNo kits yet. Create one with &e/randomkit create <name>&c.");
            return;
        }
        RandomKitPlugin.send(sender, "Kits &8(&e" + kits.size() + "&8)&7: &f" + String.join("&7, &f", kits.names()));
    }

    private void preview(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            RandomKitPlugin.send(sender, "&cOnly players can use this.");
            return;
        }
        if (args.length < 2) {
            RandomKitPlugin.send(sender, "&cUsage: /randomkit preview <name>");
            return;
        }
        KitManager.Kit kit = kits.get(args[1]);
        if (kit == null) {
            RandomKitPlugin.send(sender, "&cKit not found.");
            return;
        }
        PreviewHolder holder = new PreviewHolder();
        Inventory inv = Bukkit.createInventory(holder, 54, Component.text("Kit: " + kit.name()));
        holder.inventory = inv;

        // Main inventory rows 1-3, hotbar row 4
        kit.storage().forEach((slot, item) -> {
            if (slot >= 9 && slot <= 35) inv.setItem(slot - 9, item.clone());
            else if (slot >= 0 && slot <= 8) inv.setItem(27 + slot, item.clone());
        });
        // Armor (helmet, chestplate, leggings, boots) + offhand on row 6
        kit.armor().forEach((slot, item) -> {
            if (slot >= 0 && slot < 4) inv.setItem(45 + (3 - slot), item.clone());
        });
        if (kit.offhand() != null) inv.setItem(50, kit.offhand().clone());

        p.openInventory(inv);
    }

    private void give(CommandSender sender, String[] args, boolean random) {
        if (args.length < 2 || (!random && args.length < 3)) {
            RandomKitPlugin.send(sender, random ? "&cUsage: /randomkit random <player>" : "&cUsage: /randomkit give <player> <name>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            RandomKitPlugin.send(sender, "&cPlayer not found.");
            return;
        }
        if (random) {
            if (kits.size() == 0) {
                RandomKitPlugin.send(sender, "&cNo kits exist.");
                return;
            }
            kits.giveRandom(target);
            RandomKitPlugin.send(sender, "Gave &e" + target.getName() + "&7 a random kit.");
            return;
        }
        KitManager.Kit kit = kits.get(args[2]);
        if (kit == null) {
            RandomKitPlugin.send(sender, "&cKit not found.");
            return;
        }
        kits.give(target, kit);
        RandomKitPlugin.send(target, "You received the kit &e" + kit.name() + "&7!");
        RandomKitPlugin.send(sender, "Gave kit &e" + kit.name() + "&7 to &e" + target.getName() + "&7.");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission("randomkit.admin")) return out;
        if (args.length == 1) {
            for (String s : SUBS) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "update", "delete", "preview" -> addMatches(out, kits.names(), args[1]);
                case "give", "random" -> addMatches(out, Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(), args[1]);
                default -> { }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            addMatches(out, kits.names(), args[2]);
        }
        return out;
    }

    private void addMatches(List<String> out, List<String> source, String prefix) {
        for (String s : source) if (s.toLowerCase(Locale.ROOT).startsWith(prefix.toLowerCase(Locale.ROOT))) out.add(s);
    }
}
