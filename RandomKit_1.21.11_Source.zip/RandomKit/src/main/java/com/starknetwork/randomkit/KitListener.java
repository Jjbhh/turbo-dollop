package com.starknetwork.randomkit;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class KitListener implements Listener {

    private final RandomKitPlugin plugin;
    private final KitManager kits;
    private final Map<UUID, Long> quitTimes = new HashMap<>();

    public KitListener(RandomKitPlugin plugin, KitManager kits) {
        this.plugin = plugin;
        this.kits = kits;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Long left = quitTimes.remove(p.getUniqueId());
        if (!plugin.giveOnJoin || kits.size() == 0) return;
        if (p.hasPermission("randomkit.bypass")) return;

        // Rejoin protection: quick relog with loot = no new kit. Empty inventory = always gets a kit.
        long cooldown = plugin.rejoinCooldownMs;
        if (left != null && cooldown > 0
                && System.currentTimeMillis() - left < cooldown
                && !isInventoryEmpty(p)) {
            return;
        }

        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) kits.giveRandom(p);
        }, 2L);
    }

    private boolean isInventoryEmpty(Player p) {
        for (ItemStack it : p.getInventory().getContents()) {
            if (it != null && it.getType() != Material.AIR) return false;
        }
        return true;
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (!plugin.clearDropsOnDeath || kits.size() == 0) return;
        if (e.getPlayer().hasPermission("randomkit.bypass")) return;
        e.setKeepInventory(false);
        e.getDrops().clear();
        e.setKeepLevel(false);
        e.setDroppedExp(0);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent e) {
        if (!plugin.giveOnRespawn || kits.size() == 0) return;
        Player p = e.getPlayer();
        if (p.hasPermission("randomkit.bypass")) return;
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) kits.giveRandom(p);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        kits.forget(p);
        long now = System.currentTimeMillis();
        long keep = plugin.rejoinCooldownMs;
        // Lazy cleanup: only sweep when the map has grown, never on every quit.
        if (quitTimes.size() > 200) quitTimes.values().removeIf(t -> now - t > keep);
        if (keep > 0) quitTimes.put(p.getUniqueId(), now);
    }

    // Preview GUI is read-only.
    // These fire on EVERY inventory click on the server, so they must be as cheap as possible.
    // getHolder(false) avoids Paper creating a block-state snapshot for chests/barrels/etc.
    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (e.getInventory().getHolder(false) instanceof KitCommand.PreviewHolder) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder(false) instanceof KitCommand.PreviewHolder) e.setCancelled(true);
    }
}
