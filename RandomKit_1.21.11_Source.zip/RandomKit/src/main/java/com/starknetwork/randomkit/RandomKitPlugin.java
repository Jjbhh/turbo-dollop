package com.starknetwork.randomkit;

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public final class RandomKitPlugin extends JavaPlugin {

    private static final String PREFIX = "&6&lRandomKit &8» &7";
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    // Cached config values (read once, not on every event).
    public volatile boolean giveOnJoin = true;
    public volatile boolean giveOnRespawn = true;
    public volatile boolean clearDropsOnDeath = true;
    public volatile boolean avoidRepeat = true;
    public volatile boolean uniqueAmongPlayers = true;
    public volatile long rejoinCooldownMs = 30_000L;

    private Database db;
    private KitManager kits;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        reloadSettings();

        db = new Database(this);
        try {
            db.connect();
        } catch (Exception e) {
            getLogger().severe("Could not connect to the " + db.type() + " database: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        kits = new KitManager(this, db);
        kits.load();

        getServer().getPluginManager().registerEvents(new KitListener(this, kits), this);

        PluginCommand cmd = getCommand("randomkit");
        if (cmd != null) {
            KitCommand executor = new KitCommand(this, kits);
            cmd.setExecutor(executor);
            cmd.setTabCompleter(executor);
        }
        getLogger().info("Loaded " + kits.size() + " kit(s) from " + db.type() + ".");
    }

    @Override
    public void onDisable() {
        if (db != null) db.shutdown();
    }

    public void reloadSettings() {
        reloadConfig();
        FileConfiguration c = getConfig();
        giveOnJoin = c.getBoolean("give-on-join", true);
        giveOnRespawn = c.getBoolean("give-on-respawn", true);
        clearDropsOnDeath = c.getBoolean("clear-drops-on-death", true);
        avoidRepeat = c.getBoolean("avoid-repeat", true);
        uniqueAmongPlayers = c.getBoolean("unique-among-players", true);
        rejoinCooldownMs = Math.max(0, c.getInt("rejoin-cooldown-seconds", 30)) * 1000L;
    }

    public static void send(CommandSender to, String message) {
        to.sendMessage(LEGACY.deserialize(PREFIX + message));
    }
}
